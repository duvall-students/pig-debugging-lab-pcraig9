# PigDebugging
A Debugging Lab using the Dice Game Pig

To run the project:

run the Java class Main
right click on this class and select Run As -> Java Application
